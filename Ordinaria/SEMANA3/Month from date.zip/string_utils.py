# Escriba su código aquí
def month(date):
    return date[3:5]