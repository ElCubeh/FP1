# Escriba su código aquí
def celsius2fahrenheit(celsius):
    return celsius* 9/5 + 32