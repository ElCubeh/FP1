m = int(input("Introduce un valor entero:"))
n = int(input("Introduce otro valor entero:"))
if m % n == 0:
    print(m,"es divisible por",n)
else:
    print(m,"no es divisible por",n)