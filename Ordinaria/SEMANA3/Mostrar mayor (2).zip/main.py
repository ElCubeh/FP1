numero_1 = int(input("Introduce un valor entero: "))
numero_2 = int(input("Introduce otro valor entero: "))
if numero_1 > numero_2:
    print(numero_1)
elif numero_2 > numero_1:
    print(numero_2)
else:
    print("Iguales")