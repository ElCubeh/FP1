# Escriba su código aquí
def capital(inicial,interés,periodos):
    return inicial *(1+interés)**periodos