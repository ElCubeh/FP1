# Escriba su código aquí
def km2mi(km):
    return km*0.621371