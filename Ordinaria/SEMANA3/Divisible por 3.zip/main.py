numero = int(input("Entra un número entero: "))
if numero %3 == 0:
    print("Es divisible por 3.")
else:
    print("No es divisible por 3.")