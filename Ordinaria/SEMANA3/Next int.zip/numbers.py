# Escriba su código aquí
def next_int(n):
    return n + 1