CREATE TABLE Persons (name TEXT(40), dni TEXT(9));
INSERT INTO Persons VALUES ('Pedro Mayor Sanz', '43655032');
INSERT INTO Persons VALUES ('Juan Carlos Santana Santana', '33655113');
INSERT INTO Persons VALUES ('Ana Luisa Lopez Lopez', '44645039')