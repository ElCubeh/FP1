import number_functions

numbers1 = [1, 3, 4, 7, 8]
numbers2 = [3, 8, 5]
sun_numbers = number_functions.join_lists(numbers1, numbers2)
print(sun_numbers)
