# Escriba su código aquí
def date(dia, mes, año):
    return{'Día': dia, 'Mes': mes, 'Año': año}
