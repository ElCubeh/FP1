from functions import emparejados

set1 = {3, 5, 4, 6}
set2 = {2, 3, 5}
set3 = {3, 8, 6}

print(emparejados(set1, set2, set3))
