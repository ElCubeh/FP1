from functions import fallo_HD

set1 = {"PC001", "PC003", "PC005", "PC011"}
set2 = {"PC001", "PC005"}

print(fallo_HD(set1, set2))
