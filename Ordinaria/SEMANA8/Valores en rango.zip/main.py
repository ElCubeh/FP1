from functions import valores_en_rango

lista = [12, 34, 12, 56, 123, 12, 45]
num1 = 14
num2 = 54

print(valores_en_rango(lista, num1, num2))
