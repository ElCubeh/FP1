import dates

day = "01"
month = "06"
year = "1970"
date = (day, month, year)
result = dates.datetuple2datestr(date)
print(result)
