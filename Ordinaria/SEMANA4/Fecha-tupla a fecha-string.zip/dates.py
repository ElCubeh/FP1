# Escriba su código aquí
def datetuple2datestr(date):
    
    return date[0] + "-" + date[1] + "-" + date[2]