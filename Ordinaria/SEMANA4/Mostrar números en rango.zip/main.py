import functions

num1 = int(input("Dame un número entero: "))
num2 = int(input("Dame un otro número entero igual o mayor que el anterior: "))
functions.show_numbers(num1, num2)
