import vectors

vector1 = (1, 2, 3)
vector2 = (4, 5, 6)
result = vectors.vector_sum(vector1, vector2)
print(result)
