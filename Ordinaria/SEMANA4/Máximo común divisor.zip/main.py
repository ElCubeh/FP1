import functions

num1 = 135
num2 = 90
root = functions.mcd(num1, num2)
print(root)
