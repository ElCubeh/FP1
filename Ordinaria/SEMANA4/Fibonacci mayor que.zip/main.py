import functions

num1 = 135
result = functions.fibo_mayor_que(num1)
print(result)
