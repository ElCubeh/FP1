import functions

num1 = 25.0
num2 = 1E-10
root = functions.square_root(num1, num2)
print(root)
