# Escriba su código aquí
def datestr2datetuple(date):
    return tuple(date.split(sep= "-"))