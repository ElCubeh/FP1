import dates

date = "01-06-1970"
result = dates.datestr2datetuple(date)
print(result)
