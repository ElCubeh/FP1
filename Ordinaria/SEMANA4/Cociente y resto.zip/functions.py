# Escriba su código aquí
def division(dividendo, divisor):
    return(dividendo // divisor, dividendo % divisor)
    