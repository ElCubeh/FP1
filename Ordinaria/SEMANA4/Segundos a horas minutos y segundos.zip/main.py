import time_utils

if __name__ == "__main__":
    result = time_utils.seconds2hms(52038)
    print(result)
