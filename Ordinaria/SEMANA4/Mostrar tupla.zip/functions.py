# Escriba su código aquí
def show(tupla):
    for element in tupla:
        print (element)