import functions

t = (10, 12, 34, 56, 78, 90)
functions.show(t)
