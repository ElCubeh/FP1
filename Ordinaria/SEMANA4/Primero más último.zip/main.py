import functions

t = (14, 10, 23, 4, 12)
result = functions.first_plus_last(t)
print(result)
