import dates

day = 1
month = 6
year = 1970
result = dates.date(day, month, year)
print(result)
