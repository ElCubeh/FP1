# Escriba su código aquí
def date(day, month, year):
    return (day, month, year)
