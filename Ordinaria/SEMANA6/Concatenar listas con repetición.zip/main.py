import functions

list1 = [1, 2]
list2 = [3, 4, 5]
text = functions.concat(list1, list2)
print(text)
