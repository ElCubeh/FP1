# Escriba su código aquí
def concat(list1, list2):
    a = list1 + list2*3 + list1
    return a
