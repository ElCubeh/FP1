import functions

grades = [8, 8, 9, 5, 6, 4, 7, 4, 10]
avg = functions.avg_grade(grades)
print("la nota media es", avg)
