import finances

earnings = [1000, 200, 300, 200, 120, 100, 200, 300, 200, 120, 400, 500]
best = finances.best_semester(earnings)
print(best)
