import string_utils

names = ['Anna', 'Peter', 'Martha', 'John', 'Andrea', 'Mike']
opt = 1
filtered_names = string_utils.filter_names(names, opt)
print(filtered_names)
