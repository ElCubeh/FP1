# Escriba su código aquí
def longest(lista):
    return max(len(nombre) for nombre in lista)
