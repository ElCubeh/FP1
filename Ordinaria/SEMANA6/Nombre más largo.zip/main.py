import functions

names = ['John', 'Paul', 'Christopher', 'Peter']
length = functions.longest(names)
print("El nombre más largo tiene longitud", length)
