import functions

heights = [188, 198, 199, 1855, 196, 184, 197, 184, 210]
data = functions.smallest(heights)
print(
    "El jugador más pequeño mide",
    data[0],
    "centímetros y está en la posición",
    data[1]
)
