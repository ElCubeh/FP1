# Escriba su código aquí
def is_friend(nombres, nombre):
    if nombre in nombres:
        return True
    return False
