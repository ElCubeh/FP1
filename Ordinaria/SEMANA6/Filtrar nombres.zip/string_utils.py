# Escriba aquí su código
def filter_names(names, letter):
    return [name for name in names if name[0] == letter]
