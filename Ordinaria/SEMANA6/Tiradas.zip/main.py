import functions

throws = [4, 2, 3, 1, 4, 4, 4, 4, 6, 1, 5, 5]
frecs = functions.dice_freqs(throws)
print(frecs)
