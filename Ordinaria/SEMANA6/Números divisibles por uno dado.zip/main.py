import functions

numbers = [3, 8, 14, 33, 77, 2]
divisor = 3
found = functions.divisibles(numbers, divisor)
print("Hay", found, "números divisibles por", divisor, "en", numbers)
