import functions

list = [8, 8, 9, 5, 6, 4, 7, 4, 10]
if functions.no_decreasing(list):
    print("La lista es no decreciente")
else:
    print("La lista no es no decreciente")
