# Escriba aquí su código
def filter_numbers(numbers, start, end):
    return [number for number in numbers if start <= number <= end]
