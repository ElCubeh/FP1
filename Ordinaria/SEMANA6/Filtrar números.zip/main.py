import number_functions

numbers = [1, 4, 7, 8, 3, 10, 12, 13, 14, 15]
start = 4
end = 10
filtered_numbers = number_functions.filter_numbers(numbers, start, end)
print(filtered_numbers)
