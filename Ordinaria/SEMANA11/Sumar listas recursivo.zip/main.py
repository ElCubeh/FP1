import number_functions

numbers1 = [3, 5, 4, 3, 6]
numbers2 = [2, 3, 5, 6, 2]
sun_numbers = number_functions.sum_lists(numbers1, numbers2)
print(sun_numbers)
