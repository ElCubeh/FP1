from functions import caracteres_iguales

# Datos a procesar

string1 = "agua que no has de beber"
string2 = "déjala correr, además es lógico"

# Proceso y resultados
resultado = caracteres_iguales(string1, string2)
print(resultado)
