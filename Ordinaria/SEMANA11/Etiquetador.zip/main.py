import string_utils

test_string = "alsikjuyZB8we4 aBBe8XAZ piarBq8 Bq84Z "
pattern = "XYZAB"

print(string_utils.tagger(test_string, pattern))
