import math_utils

my_list = [12, 23, 34, 45, 67, 89]
print(math_utils.list_min(my_list))
