import string_utils

t = ("¡Hola", ", ", "mundo!")
text = string_utils.concat(t)
print(text)
