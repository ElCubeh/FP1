# Escriba su código aquí
def concat(tupla):
    resultado = ""
    for elemento in tupla:
        resultado += elemento
    return resultado
