import functions

num = int(input("Dame un número entero mayor o igual que cero: "))
fact = functions.factorial(num)
print("El factorial de", num, "es", fact)
