# Escriba su código aquí
def sum_numbers(a, b):
    sum = 0
    for i in range (a + 1, b):
        sum += i
    return sum