import functions

t = (10,  "Pedro", 42, "Margarita", 18.5, 8)
suma = functions.sum_ints(t)
print("la suma de los elementos de tipo int de la tupla es:", suma)
