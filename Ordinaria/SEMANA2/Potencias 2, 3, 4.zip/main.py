potencia=int(input("Introduce un valor entero: "))
print("Potencias: ", potencia**2,potencia**3,potencia**4)