numero = int(input("Introduce un valor entero: "))
print(numero-1)
print(numero+1)