print("Dame un texto: ")
texto = input()
print(texto)
