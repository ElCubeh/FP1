base=int(input("Base: "))
altura=int(input("Altura: "))
print("Área: ",base*altura)