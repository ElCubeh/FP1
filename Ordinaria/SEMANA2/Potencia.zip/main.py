base=int(input("Introduce la base: "))
expo=int(input("Introduce el exponente"))
print("Potencia: ",base**expo)