numero_1 =int(input("Primer número: "))
numero_2=int(input("Segundo número: "))
print(numero_1+numero_2)