fecha=input("Introduce una fecha en formato 'dd-mm-aaaa': ")
mes = fecha[3:5]
print("El mes es: ", mes)