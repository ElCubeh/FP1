numero = int(input("Dame un número entero:"))
print(numero + 1)