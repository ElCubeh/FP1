base=int(input("Base: "))
altura=int(input("Altura: "))
print("Perímetro: ",base*2+altura*2)