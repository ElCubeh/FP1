print("Escuela de Ingeniería Informática.")
print("Edificio Departamental de Informática y Matemáticas.")
print("Campus Universitario de Tafira.")