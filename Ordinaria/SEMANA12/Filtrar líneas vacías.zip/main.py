import file_utils
import string_utils

string_utils.no_empty_lines("input.txt", "output.txt")
file_utils.show_file("output.txt")
