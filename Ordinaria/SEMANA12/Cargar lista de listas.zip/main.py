import string_utils

resulting_list = string_utils.load_list("input.txt")
print(resulting_list)
