import file_utils
import string_utils

string_utils.save_initials("input.txt", "output.txt")
file_utils.show_file("output.txt")
