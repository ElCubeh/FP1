import file_utils
import string_utils

string_utils.words_frec("input.txt", "output.csv")
file_utils.show_file("output.csv")
