import math_utils

test_exp = ((56, '+', (5, '*', 2)), '/', (12, '-', 2))
print(math_utils.evaluate(test_exp))
