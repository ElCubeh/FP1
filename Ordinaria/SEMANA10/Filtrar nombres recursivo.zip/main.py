import string_utils

names = ['John', 'Paul', 'Martin', 'Peter', 'Max', 'Mia']
initial = 'M'
filtered_names = string_utils.filter_names(names, initial)
print(filtered_names)
