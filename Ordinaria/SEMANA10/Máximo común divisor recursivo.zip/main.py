import functions

print(functions.mcd(135, 40))
