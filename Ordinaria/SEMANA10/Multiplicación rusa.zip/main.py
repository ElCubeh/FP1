import functions

num1 = 5
num2 = 6
prod = functions.product(num1, num2)
print(prod)
