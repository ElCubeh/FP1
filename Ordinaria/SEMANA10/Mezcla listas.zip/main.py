import math_utils

l1 = [12, 23, 34, 45, 67, 89]
l2 = [10, 12, 35, 43, 65]
print(math_utils.merge(l1, l2))
