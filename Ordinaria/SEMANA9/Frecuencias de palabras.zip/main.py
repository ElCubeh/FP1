import string_utils

text = "Esto es una string, no es una lista"
frecs = string_utils.words_frecs(text)
print(frecs)
