import string_utils

print(string_utils.swap("esto es una STRING de prueba"))
