import string_utils

print(
    string_utils.longest_word(
        "El policía alto dio el alto al ladrón maniático"
    )
)
