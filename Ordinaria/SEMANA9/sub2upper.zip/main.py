import string_utils

print(
    string_utils.sub2upper(
        "El policia alto dio el alto al ladrón alto en el alto", "alto"
    )
)
