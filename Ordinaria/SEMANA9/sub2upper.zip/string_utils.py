# Escriba aquí su código
def sub2upper(str1, str2):
    return str1.replace(str2, str2.upper())
