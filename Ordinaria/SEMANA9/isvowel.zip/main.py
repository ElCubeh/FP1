import string_utils

print(string_utils.isvowel("aeouieeÍo"))
print(string_utils.isvowel("Hola mundo"))
