# Escriba su código aquí
def celsius2fahrenheit(temp_celsius):
    tem_fahrenheit = (temp_celsius * 9/5) + 32
    return f"{temp_celsius:.1f} grados Celsius equivalen a {temp_fahrenheit:.1f} grados Fahrenheit"
