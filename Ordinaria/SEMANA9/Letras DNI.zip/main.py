import string_utils

persons = {
    "11111111": "John Doe",
    "12345678": "Périco de los Palotes",
    "42123456": "Jaimito Chistes"
}
string_utils.change_dict(persons)
print(persons)
