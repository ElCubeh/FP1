import string_utils

text = "Esto es una string de prueba"
frecs = string_utils.chars_frecs(text)
print(frecs)
