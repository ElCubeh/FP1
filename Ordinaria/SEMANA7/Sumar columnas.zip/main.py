import matrix_functions

numbers = [
    [1,  3,  4,  7],
    [8,  3, 10, 12],
    [3, 14, 15,  0]
]
result = matrix_functions.sum_columns(numbers)
print(result)
