import number_functions

numbers1 = [1, 3, 4, 7, 8, 3]
numbers2 = [3, 8, 5]
sum_numbers = number_functions.maxs(numbers1, numbers2)
print(sum_numbers)
