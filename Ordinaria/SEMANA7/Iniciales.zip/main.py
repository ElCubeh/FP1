import string_utils

names = [
    ['Juan', 'Pedro', 'Sofia', 'Elena'],
    ['Octavio', 'Gustavo', 'José', 'Mária', 'Leopoldo'],
    ['Francisco', 'Herminia', 'Nauzet'],
    ['Yaiza', 'Idafen']
]
result = string_utils.initials(names)
print(result)
