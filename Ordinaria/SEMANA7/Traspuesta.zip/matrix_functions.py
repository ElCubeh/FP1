# Escriba aquí su código
def transpose(matriz):
    return [[row[i] for row in matriz] for i in range(len(matriz[0]))]
