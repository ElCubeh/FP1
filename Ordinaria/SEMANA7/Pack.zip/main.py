import number_functions

numbers1 = [1, 3, 4]
numbers2 = [3, 8, 5]
result = number_functions.pack(numbers1, numbers2)
print(result)
