# Escriba aquí su código
def pack(lista1, lista2):
    result = []
    for i in range(len(lista1)):
        result.append((lista1[i], lista2[i]))
    return result
