import matrix_functions

numbers = [
    [3,  5,  4,  3],
    [5,  7,  5,  8],
    [4,  5,  5,  0],
    [3,  8,  0,  9]
]
result = matrix_functions.symmetrical(numbers)
print(result)
