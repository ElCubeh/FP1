import matrices

matrix = ((10, 21, 13), (4, 5, 6), (8, 12, 34))
result = matrices.min_of_matrix(matrix)
print(result)
