# Escriba aquí su código
def change_sign(num_list):
    for i in range(len(num_list)):
        num_list[i] = - num_list[i]
    return num_list
