import number_functions

numbers = [1, 4, 7, 8, 3, 10, 12, 13, 14, 15]
number_functions.change_sign(numbers)
print(numbers)
