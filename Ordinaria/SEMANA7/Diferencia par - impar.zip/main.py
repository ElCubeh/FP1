import number_functions

numbers1 = [3, 5, 4, 3, 6]
numbers2 = [2, 3, 5, 8, 2]
par_impar = number_functions.dif_par_impar(numbers1, numbers2)
print(par_impar)
