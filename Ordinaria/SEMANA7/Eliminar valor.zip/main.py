import number_functions

numbers = [1, 4, 7, 8, 3, 10, 12, 13, 14, 15]
value = 8
number_functions.delete_value(numbers, value)
print(numbers)
