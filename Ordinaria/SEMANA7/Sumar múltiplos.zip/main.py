import number_functions

numbers1 = [3, 5, 4, 3, 6, 8]
numbers2 = [2, 3, 5, 8, 2, 4]
mul = 3
suma = number_functions.sumar_multiplos(numbers1, numbers2, mul)
print(suma)
