import number_functions

numbers = [1, 3, 4, 7, 8, 3, 10, 12, 3, 14, 15]
counters = [3, 8, 5]
number_functions.count_values(numbers, counters)
print(counters)
